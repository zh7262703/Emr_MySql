﻿namespace Base_Function.BLL_DIAGNOSE
{
    partial class frmDiagnoseSimple
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tcDiagnose = new DevComponents.DotNetBar.TabControl();
            this.tcpWestern = new DevComponents.DotNetBar.TabControlPanel();
            this.atDiagnoseList = new DevComponents.AdvTree.AdvTree();
            this.columnHeader3 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader4 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader15 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader5 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader6 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader7 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader8 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader9 = new DevComponents.AdvTree.ColumnHeader();
            this.cmsDiagnose = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.复制诊断ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.添加附属诊断ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加为常用诊断ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.修改诊断ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除诊断ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.elementStyle1 = new DevComponents.DotNetBar.ElementStyle();
            this.node1 = new DevComponents.AdvTree.Node();
            this.cell1 = new DevComponents.AdvTree.Cell();
            this.cell7 = new DevComponents.AdvTree.Cell();
            this.cell2 = new DevComponents.AdvTree.Cell();
            this.cell3 = new DevComponents.AdvTree.Cell();
            this.cell4 = new DevComponents.AdvTree.Cell();
            this.cell5 = new DevComponents.AdvTree.Cell();
            this.cell6 = new DevComponents.AdvTree.Cell();
            this.node2 = new DevComponents.AdvTree.Node();
            this.nodeConnector1 = new DevComponents.AdvTree.NodeConnector();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.labelItem1 = new DevComponents.DotNetBar.LabelItem();
            this.checkBoxItem2 = new DevComponents.DotNetBar.CheckBoxItem();
            this.labelItem2 = new DevComponents.DotNetBar.LabelItem();
            this.biUp = new DevComponents.DotNetBar.ButtonItem();
            this.biDown = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem3 = new DevComponents.DotNetBar.ButtonItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnClear = new DevComponents.DotNetBar.ButtonX();
            this.btnAdd = new DevComponents.DotNetBar.ButtonX();
            this.txtDiagnose = new TextEditor.TextDocument.Control.AutoTextBox();
            this.lblIcd10Encode = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabItem1 = new DevComponents.DotNetBar.TabItem(this.components);
            this.tcpChinese = new DevComponents.DotNetBar.TabControlPanel();
            this.atChineseDiagnose = new DevComponents.AdvTree.AdvTree();
            this.columnHeader1 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader2 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader17 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader16 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader10 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader11 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader12 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader13 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader14 = new DevComponents.AdvTree.ColumnHeader();
            this.cmsChineseDiagnose = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.复制诊断到ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.添加为常用诊断ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.node3 = new DevComponents.AdvTree.Node();
            this.node4 = new DevComponents.AdvTree.Node();
            this.nodeConnector2 = new DevComponents.AdvTree.NodeConnector();
            this.ribbonBar2 = new DevComponents.DotNetBar.RibbonBar();
            this.labelItem3 = new DevComponents.DotNetBar.LabelItem();
            this.checkBoxItem1 = new DevComponents.DotNetBar.CheckBoxItem();
            this.labelItem4 = new DevComponents.DotNetBar.LabelItem();
            this.buttonItem1 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem2 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem4 = new DevComponents.DotNetBar.ButtonItem();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnChineseClear = new DevComponents.DotNetBar.ButtonX();
            this.btnChineseAdd = new DevComponents.DotNetBar.ButtonX();
            this.txtZh = new TextEditor.TextDocument.Control.AutoTextBox();
            this.lbChineseZhIcd = new System.Windows.Forms.Label();
            this.txtBm = new TextEditor.TextDocument.Control.AutoTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lbChineseBmIcd = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabItem2 = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel1 = new DevComponents.DotNetBar.TabControlPanel();
            this.tabItem3 = new DevComponents.DotNetBar.TabItem(this.components);
            this.elementStyle4 = new DevComponents.DotNetBar.ElementStyle();
            this.elementStyle3 = new DevComponents.DotNetBar.ElementStyle();
            this.elementStyle2 = new DevComponents.DotNetBar.ElementStyle();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tcDiagnose)).BeginInit();
            this.tcDiagnose.SuspendLayout();
            this.tcpWestern.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.atDiagnoseList)).BeginInit();
            this.cmsDiagnose.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tcpChinese.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.atChineseDiagnose)).BeginInit();
            this.cmsChineseDiagnose.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tcDiagnose, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 456F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 456F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1095, 544);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tcDiagnose
            // 
            this.tcDiagnose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(217)))), ((int)(((byte)(247)))));
            this.tcDiagnose.CanReorderTabs = true;
            this.tcDiagnose.Controls.Add(this.tabControlPanel1);
            this.tcDiagnose.Controls.Add(this.tcpWestern);
            this.tcDiagnose.Controls.Add(this.tcpChinese);
            this.tcDiagnose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcDiagnose.Location = new System.Drawing.Point(1, 1);
            this.tcDiagnose.Margin = new System.Windows.Forms.Padding(0);
            this.tcDiagnose.Name = "tcDiagnose";
            this.tcDiagnose.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.tcDiagnose.SelectedTabIndex = 0;
            this.tcDiagnose.Size = new System.Drawing.Size(1093, 542);
            this.tcDiagnose.Style = DevComponents.DotNetBar.eTabStripStyle.Office2007Document;
            this.tcDiagnose.TabIndex = 4;
            this.tcDiagnose.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tcDiagnose.Tabs.Add(this.tabItem1);
            this.tcDiagnose.Tabs.Add(this.tabItem2);
            this.tcDiagnose.Tabs.Add(this.tabItem3);
            // 
            // tcpWestern
            // 
            this.tcpWestern.Controls.Add(this.atDiagnoseList);
            this.tcpWestern.Controls.Add(this.ribbonBar1);
            this.tcpWestern.Controls.Add(this.panel1);
            this.tcpWestern.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcpWestern.Location = new System.Drawing.Point(0, 25);
            this.tcpWestern.Name = "tcpWestern";
            this.tcpWestern.Padding = new System.Windows.Forms.Padding(1);
            this.tcpWestern.Size = new System.Drawing.Size(1093, 517);
            this.tcpWestern.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.tcpWestern.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(227)))));
            this.tcpWestern.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tcpWestern.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tcpWestern.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tcpWestern.Style.GradientAngle = 90;
            this.tcpWestern.TabIndex = 1;
            this.tcpWestern.TabItem = this.tabItem1;
            // 
            // atDiagnoseList
            // 
            this.atDiagnoseList.AccessibleRole = System.Windows.Forms.AccessibleRole.Outline;
            this.atDiagnoseList.AllowDrop = true;
            this.atDiagnoseList.BackColor = System.Drawing.SystemColors.Window;
            // 
            // 
            // 
            this.atDiagnoseList.BackgroundStyle.Class = "TreeBorderKey";
            this.atDiagnoseList.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.atDiagnoseList.Columns.Add(this.columnHeader3);
            this.atDiagnoseList.Columns.Add(this.columnHeader4);
            this.atDiagnoseList.Columns.Add(this.columnHeader15);
            this.atDiagnoseList.Columns.Add(this.columnHeader5);
            this.atDiagnoseList.Columns.Add(this.columnHeader6);
            this.atDiagnoseList.Columns.Add(this.columnHeader7);
            this.atDiagnoseList.Columns.Add(this.columnHeader8);
            this.atDiagnoseList.Columns.Add(this.columnHeader9);
            this.atDiagnoseList.ContextMenuStrip = this.cmsDiagnose;
            this.atDiagnoseList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.atDiagnoseList.DoubleClickTogglesNode = false;
            this.atDiagnoseList.DragDropEnabled = false;
            this.atDiagnoseList.ExpandButtonSize = new System.Drawing.Size(12, 8);
            this.atDiagnoseList.ExpandButtonType = DevComponents.AdvTree.eExpandButtonType.Triangle;
            this.atDiagnoseList.ExpandLineColor = System.Drawing.Color.White;
            this.atDiagnoseList.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.atDiagnoseList.GridLinesColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.atDiagnoseList.GridRowLines = true;
            this.atDiagnoseList.GroupNodeStyle = this.elementStyle1;
            this.atDiagnoseList.Location = new System.Drawing.Point(1, 101);
            this.atDiagnoseList.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.atDiagnoseList.Name = "atDiagnoseList";
            this.atDiagnoseList.Nodes.AddRange(new DevComponents.AdvTree.Node[] {
            this.node1});
            this.atDiagnoseList.NodesColumnsBackgroundStyle = this.elementStyle1;
            this.atDiagnoseList.NodesConnector = this.nodeConnector1;
            this.atDiagnoseList.NodeStyle = this.elementStyle1;
            this.atDiagnoseList.NodeStyleSelected = this.elementStyle1;
            this.atDiagnoseList.PathSeparator = ";";
            this.atDiagnoseList.SelectionBoxStyle = DevComponents.AdvTree.eSelectionStyle.FullRowSelect;
            this.atDiagnoseList.Size = new System.Drawing.Size(1091, 415);
            this.atDiagnoseList.TabIndex = 4;
            this.atDiagnoseList.DoubleClick += new System.EventHandler(this.atDiagnoseList_DoubleClick);
            this.atDiagnoseList.AfterCheck += new DevComponents.AdvTree.AdvTreeCellEventHandler(this.atDiagnoseList_AfterCheck);
            this.atDiagnoseList.NodeMouseDown += new DevComponents.AdvTree.TreeNodeMouseEventHandler(this.atDiagnoseList_NodeMouseDown);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Name = "columnHeader3";
            this.columnHeader3.Text = "诊断名称";
            this.columnHeader3.Width.Absolute = 300;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Name = "columnHeader4";
            this.columnHeader4.Text = "诊断编码";
            this.columnHeader4.Width.Absolute = 140;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Name = "columnHeader15";
            this.columnHeader15.Text = "诊断类型";
            this.columnHeader15.Width.Absolute = 69;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Name = "columnHeader5";
            this.columnHeader5.Text = "诊断日期";
            this.columnHeader5.Width.Absolute = 120;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Name = "columnHeader6";
            this.columnHeader6.Text = "附属书写";
            this.columnHeader6.Width.Absolute = 69;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Name = "columnHeader7";
            this.columnHeader7.Text = "一级书写";
            this.columnHeader7.Width.Absolute = 69;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Name = "columnHeader8";
            this.columnHeader8.Text = "二级书写";
            this.columnHeader8.Width.Absolute = 69;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Name = "columnHeader9";
            this.columnHeader9.Text = "三级书写";
            this.columnHeader9.Width.Absolute = 69;
            // 
            // cmsDiagnose
            // 
            this.cmsDiagnose.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.复制诊断ToolStripMenuItem,
            this.toolStripSeparator3,
            this.添加附属诊断ToolStripMenuItem,
            this.添加为常用诊断ToolStripMenuItem,
            this.toolStripSeparator1,
            this.修改诊断ToolStripMenuItem,
            this.删除诊断ToolStripMenuItem});
            this.cmsDiagnose.Name = "cmsDiagnose";
            this.cmsDiagnose.Size = new System.Drawing.Size(159, 126);
            this.cmsDiagnose.Opening += new System.ComponentModel.CancelEventHandler(this.cmsDiagnose_Opening);
            // 
            // 复制诊断ToolStripMenuItem
            // 
            this.复制诊断ToolStripMenuItem.Name = "复制诊断ToolStripMenuItem";
            this.复制诊断ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.复制诊断ToolStripMenuItem.Text = "复制诊断到";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(155, 6);
            // 
            // 添加附属诊断ToolStripMenuItem
            // 
            this.添加附属诊断ToolStripMenuItem.Name = "添加附属诊断ToolStripMenuItem";
            this.添加附属诊断ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.添加附属诊断ToolStripMenuItem.Text = "添加附属诊断";
            this.添加附属诊断ToolStripMenuItem.Click += new System.EventHandler(this.添加附属诊断ToolStripMenuItem_Click);
            // 
            // 添加为常用诊断ToolStripMenuItem
            // 
            this.添加为常用诊断ToolStripMenuItem.Name = "添加为常用诊断ToolStripMenuItem";
            this.添加为常用诊断ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.添加为常用诊断ToolStripMenuItem.Tag = "N";
            this.添加为常用诊断ToolStripMenuItem.Text = "添加为常用诊断";
            this.添加为常用诊断ToolStripMenuItem.Click += new System.EventHandler(this.添加为常用诊断ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(155, 6);
            // 
            // 修改诊断ToolStripMenuItem
            // 
            this.修改诊断ToolStripMenuItem.Name = "修改诊断ToolStripMenuItem";
            this.修改诊断ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.修改诊断ToolStripMenuItem.Text = "修改诊断";
            this.修改诊断ToolStripMenuItem.Click += new System.EventHandler(this.修改诊断ToolStripMenuItem_Click);
            // 
            // 删除诊断ToolStripMenuItem
            // 
            this.删除诊断ToolStripMenuItem.Name = "删除诊断ToolStripMenuItem";
            this.删除诊断ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.删除诊断ToolStripMenuItem.Text = "删除诊断";
            this.删除诊断ToolStripMenuItem.Click += new System.EventHandler(this.删除诊断ToolStripMenuItem_Click);
            // 
            // elementStyle1
            // 
            this.elementStyle1.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.elementStyle1.Name = "elementStyle1";
            this.elementStyle1.TextColor = System.Drawing.SystemColors.ControlText;
            // 
            // node1
            // 
            this.node1.Cells.Add(this.cell1);
            this.node1.Cells.Add(this.cell7);
            this.node1.Cells.Add(this.cell2);
            this.node1.Cells.Add(this.cell3);
            this.node1.Cells.Add(this.cell4);
            this.node1.Cells.Add(this.cell5);
            this.node1.Cells.Add(this.cell6);
            this.node1.Expanded = true;
            this.node1.Name = "node1";
            this.node1.Nodes.AddRange(new DevComponents.AdvTree.Node[] {
            this.node2});
            this.node1.Text = "间歇性抽风";
            // 
            // cell1
            // 
            this.cell1.Name = "cell1";
            this.cell1.StyleMouseOver = null;
            this.cell1.Text = "code1023223";
            // 
            // cell7
            // 
            this.cell7.Name = "cell7";
            this.cell7.StyleMouseOver = null;
            this.cell7.Text = "初步诊断";
            // 
            // cell2
            // 
            this.cell2.Name = "cell2";
            this.cell2.StyleMouseOver = null;
            this.cell2.Text = "2012-10-10 10:10";
            // 
            // cell3
            // 
            this.cell3.Name = "cell3";
            this.cell3.StyleMouseOver = null;
            this.cell3.Text = "冯敬尧";
            // 
            // cell4
            // 
            this.cell4.Name = "cell4";
            this.cell4.StyleMouseOver = null;
            this.cell4.Text = "冯程程";
            // 
            // cell5
            // 
            this.cell5.Name = "cell5";
            this.cell5.StyleMouseOver = null;
            this.cell5.Text = "丁力";
            // 
            // cell6
            // 
            this.cell6.Name = "cell6";
            this.cell6.StyleMouseOver = null;
            this.cell6.Text = "许文强";
            // 
            // node2
            // 
            this.node2.Expanded = true;
            this.node2.Name = "node2";
            this.node2.Text = "node2";
            // 
            // nodeConnector1
            // 
            this.nodeConnector1.LineColor = System.Drawing.SystemColors.ControlText;
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribbonBar1.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.ribbonBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem1,
            this.checkBoxItem2,
            this.labelItem2,
            this.biUp,
            this.biDown,
            this.buttonItem3});
            this.ribbonBar1.Location = new System.Drawing.Point(1, 71);
            this.ribbonBar1.Margin = new System.Windows.Forms.Padding(0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(1091, 30);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar1.TabIndex = 1;
            this.ribbonBar1.Text = "ribbonBar1";
            // 
            // 
            // 
            this.ribbonBar1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.TitleVisible = false;
            // 
            // labelItem1
            // 
            this.labelItem1.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.labelItem1.Name = "labelItem1";
            this.labelItem1.Text = "   ";
            // 
            // checkBoxItem2
            // 
            this.checkBoxItem2.Name = "checkBoxItem2";
            this.checkBoxItem2.Text = "全选";
            this.checkBoxItem2.Click += new System.EventHandler(this.cbiSelectAll_Click);
            // 
            // labelItem2
            // 
            this.labelItem2.Name = "labelItem2";
            this.labelItem2.Text = "   ";
            this.labelItem2.Width = 100;
            // 
            // biUp
            // 
            this.biUp.Name = "biUp";
            this.biUp.SubItemsExpandWidth = 14;
            this.biUp.Text = "上移";
            this.biUp.Click += new System.EventHandler(this.biUp_Click);
            // 
            // biDown
            // 
            this.biDown.Name = "biDown";
            this.biDown.SubItemsExpandWidth = 14;
            this.biDown.Text = "下移";
            this.biDown.Click += new System.EventHandler(this.biDown_Click);
            // 
            // buttonItem3
            // 
            this.buttonItem3.Name = "buttonItem3";
            this.buttonItem3.SubItemsExpandWidth = 14;
            this.buttonItem3.Text = "上级审签";
            this.buttonItem3.Click += new System.EventHandler(this.buttonItem3_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.txtDiagnose);
            this.panel1.Controls.Add(this.lblIcd10Encode);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1091, 70);
            this.panel1.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker1.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(100, 39);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ShowUpDown = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(140, 24);
            this.dateTimePicker1.TabIndex = 5;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label9.Location = new System.Drawing.Point(57, 42);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 19);
            this.label9.TabIndex = 4;
            this.label9.Text = "时间：";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ItemHeight = 19;
            this.comboBox1.Location = new System.Drawing.Point(100, 6);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(140, 27);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label3.Location = new System.Drawing.Point(57, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "类型：";
            // 
            // btnClear
            // 
            this.btnClear.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnClear.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnClear.Location = new System.Drawing.Point(967, 22);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(64, 27);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "清空";
            this.btnClear.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnAdd.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnAdd.Location = new System.Drawing.Point(897, 22);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(64, 27);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "保存";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtDiagnose
            // 
            this.txtDiagnose.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDiagnose.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtDiagnose.Location = new System.Drawing.Point(315, 23);
            this.txtDiagnose.Name = "txtDiagnose";
            this.txtDiagnose.Size = new System.Drawing.Size(377, 24);
            this.txtDiagnose.TabIndex = 1;
            // 
            // lblIcd10Encode
            // 
            this.lblIcd10Encode.AutoSize = true;
            this.lblIcd10Encode.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.lblIcd10Encode.Location = new System.Drawing.Point(763, 26);
            this.lblIcd10Encode.Name = "lblIcd10Encode";
            this.lblIcd10Encode.Size = new System.Drawing.Size(0, 19);
            this.lblIcd10Encode.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label2.Location = new System.Drawing.Point(694, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "ICD编码：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label1.Location = new System.Drawing.Point(261, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "名称：";
            // 
            // tabItem1
            // 
            this.tabItem1.AttachedControl = this.tcpWestern;
            this.tabItem1.Name = "tabItem1";
            this.tabItem1.Text = "西医诊断";
            this.tabItem1.Click += new System.EventHandler(this.tabItem1_Click);
            // 
            // tcpChinese
            // 
            this.tcpChinese.Controls.Add(this.atChineseDiagnose);
            this.tcpChinese.Controls.Add(this.ribbonBar2);
            this.tcpChinese.Controls.Add(this.panel3);
            this.tcpChinese.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcpChinese.Location = new System.Drawing.Point(0, 25);
            this.tcpChinese.Name = "tcpChinese";
            this.tcpChinese.Padding = new System.Windows.Forms.Padding(1);
            this.tcpChinese.Size = new System.Drawing.Size(1093, 517);
            this.tcpChinese.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.tcpChinese.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(227)))));
            this.tcpChinese.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tcpChinese.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tcpChinese.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tcpChinese.Style.GradientAngle = 90;
            this.tcpChinese.TabIndex = 2;
            this.tcpChinese.TabItem = this.tabItem2;
            // 
            // atChineseDiagnose
            // 
            this.atChineseDiagnose.AccessibleRole = System.Windows.Forms.AccessibleRole.Outline;
            this.atChineseDiagnose.AllowDrop = true;
            this.atChineseDiagnose.BackColor = System.Drawing.SystemColors.Window;
            // 
            // 
            // 
            this.atChineseDiagnose.BackgroundStyle.Class = "TreeBorderKey";
            this.atChineseDiagnose.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.atChineseDiagnose.Columns.Add(this.columnHeader1);
            this.atChineseDiagnose.Columns.Add(this.columnHeader2);
            this.atChineseDiagnose.Columns.Add(this.columnHeader17);
            this.atChineseDiagnose.Columns.Add(this.columnHeader16);
            this.atChineseDiagnose.Columns.Add(this.columnHeader10);
            this.atChineseDiagnose.Columns.Add(this.columnHeader11);
            this.atChineseDiagnose.Columns.Add(this.columnHeader12);
            this.atChineseDiagnose.Columns.Add(this.columnHeader13);
            this.atChineseDiagnose.Columns.Add(this.columnHeader14);
            this.atChineseDiagnose.ContextMenuStrip = this.cmsChineseDiagnose;
            this.atChineseDiagnose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.atChineseDiagnose.DoubleClickTogglesNode = false;
            this.atChineseDiagnose.DragDropEnabled = false;
            this.atChineseDiagnose.ExpandButtonSize = new System.Drawing.Size(12, 8);
            this.atChineseDiagnose.ExpandButtonType = DevComponents.AdvTree.eExpandButtonType.Triangle;
            this.atChineseDiagnose.ExpandLineColor = System.Drawing.Color.White;
            this.atChineseDiagnose.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.atChineseDiagnose.GridLinesColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.atChineseDiagnose.GridRowLines = true;
            this.atChineseDiagnose.GroupNodeStyle = this.elementStyle1;
            this.atChineseDiagnose.Location = new System.Drawing.Point(1, 102);
            this.atChineseDiagnose.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.atChineseDiagnose.Name = "atChineseDiagnose";
            this.atChineseDiagnose.Nodes.AddRange(new DevComponents.AdvTree.Node[] {
            this.node3});
            this.atChineseDiagnose.NodesColumnsBackgroundStyle = this.elementStyle1;
            this.atChineseDiagnose.NodesConnector = this.nodeConnector2;
            this.atChineseDiagnose.NodeStyle = this.elementStyle1;
            this.atChineseDiagnose.NodeStyleSelected = this.elementStyle1;
            this.atChineseDiagnose.PathSeparator = ";";
            this.atChineseDiagnose.SelectionBoxStyle = DevComponents.AdvTree.eSelectionStyle.FullRowSelect;
            this.atChineseDiagnose.Size = new System.Drawing.Size(1091, 414);
            this.atChineseDiagnose.TabIndex = 5;
            this.atChineseDiagnose.DoubleClick += new System.EventHandler(this.atChineseDiagnose_DoubleClick);
            this.atChineseDiagnose.AfterCheck += new DevComponents.AdvTree.AdvTreeCellEventHandler(this.atChineseDiagnose_AfterCheck);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Name = "columnHeader1";
            this.columnHeader1.Text = "病名";
            this.columnHeader1.Width.Absolute = 220;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Name = "columnHeader2";
            this.columnHeader2.Text = "症候";
            this.columnHeader2.Width.Absolute = 220;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Name = "columnHeader17";
            this.columnHeader17.Text = "诊断编码";
            this.columnHeader17.Width.Absolute = 140;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Name = "columnHeader16";
            this.columnHeader16.Text = "诊断类型";
            this.columnHeader16.Width.Absolute = 69;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Name = "columnHeader10";
            this.columnHeader10.Text = "诊断日期";
            this.columnHeader10.Width.Absolute = 120;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Name = "columnHeader11";
            this.columnHeader11.Text = "附属书写";
            this.columnHeader11.Width.Absolute = 69;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Name = "columnHeader12";
            this.columnHeader12.Text = "一级书写";
            this.columnHeader12.Width.Absolute = 69;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Name = "columnHeader13";
            this.columnHeader13.Text = "二级书写";
            this.columnHeader13.Width.Absolute = 69;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Name = "columnHeader14";
            this.columnHeader14.Text = "三级书写";
            this.columnHeader14.Width.Absolute = 69;
            // 
            // cmsChineseDiagnose
            // 
            this.cmsChineseDiagnose.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.复制诊断到ToolStripMenuItem,
            this.toolStripSeparator4,
            this.toolStripMenuItem1,
            this.添加为常用诊断ToolStripMenuItem1,
            this.toolStripSeparator2,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.cmsChineseDiagnose.Name = "cmsDiagnose";
            this.cmsChineseDiagnose.Size = new System.Drawing.Size(159, 126);
            this.cmsChineseDiagnose.Opening += new System.ComponentModel.CancelEventHandler(this.cmsChineseDiagnose_Opening);
            // 
            // 复制诊断到ToolStripMenuItem
            // 
            this.复制诊断到ToolStripMenuItem.Name = "复制诊断到ToolStripMenuItem";
            this.复制诊断到ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.复制诊断到ToolStripMenuItem.Text = "复制诊断到";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(155, 6);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem1.Text = "添加附属诊断";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // 添加为常用诊断ToolStripMenuItem1
            // 
            this.添加为常用诊断ToolStripMenuItem1.Name = "添加为常用诊断ToolStripMenuItem1";
            this.添加为常用诊断ToolStripMenuItem1.Size = new System.Drawing.Size(158, 22);
            this.添加为常用诊断ToolStripMenuItem1.Tag = "Y";
            this.添加为常用诊断ToolStripMenuItem1.Text = "添加为常用诊断";
            this.添加为常用诊断ToolStripMenuItem1.Click += new System.EventHandler(this.添加为常用诊断ToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(155, 6);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem2.Text = "修改诊断";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem3.Text = "删除诊断";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // node3
            // 
            this.node3.Expanded = true;
            this.node3.Name = "node3";
            this.node3.Nodes.AddRange(new DevComponents.AdvTree.Node[] {
            this.node4});
            this.node3.Text = "node1";
            // 
            // node4
            // 
            this.node4.Expanded = true;
            this.node4.Name = "node4";
            this.node4.Text = "node2";
            // 
            // nodeConnector2
            // 
            this.nodeConnector2.LineColor = System.Drawing.SystemColors.ControlText;
            // 
            // ribbonBar2
            // 
            this.ribbonBar2.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar2.ContainerControlProcessDialogKey = true;
            this.ribbonBar2.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribbonBar2.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.ribbonBar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem3,
            this.checkBoxItem1,
            this.labelItem4,
            this.buttonItem1,
            this.buttonItem2,
            this.buttonItem4});
            this.ribbonBar2.Location = new System.Drawing.Point(1, 72);
            this.ribbonBar2.Margin = new System.Windows.Forms.Padding(0);
            this.ribbonBar2.Name = "ribbonBar2";
            this.ribbonBar2.Size = new System.Drawing.Size(1091, 30);
            this.ribbonBar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar2.TabIndex = 4;
            this.ribbonBar2.Text = "ribbonBar2";
            // 
            // 
            // 
            this.ribbonBar2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar2.TitleVisible = false;
            // 
            // labelItem3
            // 
            this.labelItem3.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.labelItem3.Name = "labelItem3";
            this.labelItem3.Text = "   ";
            // 
            // checkBoxItem1
            // 
            this.checkBoxItem1.Name = "checkBoxItem1";
            this.checkBoxItem1.Text = "全选";
            this.checkBoxItem1.Click += new System.EventHandler(this.checkBoxItem1_Click);
            // 
            // labelItem4
            // 
            this.labelItem4.Name = "labelItem4";
            this.labelItem4.Text = "   ";
            this.labelItem4.Width = 100;
            // 
            // buttonItem1
            // 
            this.buttonItem1.Name = "buttonItem1";
            this.buttonItem1.SubItemsExpandWidth = 14;
            this.buttonItem1.Text = "上移";
            this.buttonItem1.Click += new System.EventHandler(this.buttonItem1_Click);
            // 
            // buttonItem2
            // 
            this.buttonItem2.Name = "buttonItem2";
            this.buttonItem2.SubItemsExpandWidth = 14;
            this.buttonItem2.Text = "下移";
            this.buttonItem2.Click += new System.EventHandler(this.buttonItem2_Click);
            // 
            // buttonItem4
            // 
            this.buttonItem4.Name = "buttonItem4";
            this.buttonItem4.SubItemsExpandWidth = 14;
            this.buttonItem4.Text = "上级审签";
            this.buttonItem4.Click += new System.EventHandler(this.buttonItem4_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.dateTimePicker2);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.comboBox2);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.btnChineseClear);
            this.panel3.Controls.Add(this.btnChineseAdd);
            this.panel3.Controls.Add(this.txtZh);
            this.panel3.Controls.Add(this.lbChineseZhIcd);
            this.panel3.Controls.Add(this.txtBm);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.lbChineseBmIcd);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(1, 1);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1091, 71);
            this.panel3.TabIndex = 3;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dateTimePicker2.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(101, 39);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.ShowUpDown = true;
            this.dateTimePicker2.Size = new System.Drawing.Size(140, 24);
            this.dateTimePicker2.TabIndex = 7;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label10.Location = new System.Drawing.Point(58, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 19);
            this.label10.TabIndex = 6;
            this.label10.Text = "时间：";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(101, 7);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(140, 27);
            this.comboBox2.TabIndex = 0;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label4.Location = new System.Drawing.Point(58, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 19);
            this.label4.TabIndex = 5;
            this.label4.Text = "类型：";
            // 
            // btnChineseClear
            // 
            this.btnChineseClear.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnChineseClear.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnChineseClear.Location = new System.Drawing.Point(969, 22);
            this.btnChineseClear.Name = "btnChineseClear";
            this.btnChineseClear.Size = new System.Drawing.Size(64, 27);
            this.btnChineseClear.TabIndex = 4;
            this.btnChineseClear.Text = "清空";
            this.btnChineseClear.Click += new System.EventHandler(this.btnChineseClear_Click);
            // 
            // btnChineseAdd
            // 
            this.btnChineseAdd.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnChineseAdd.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnChineseAdd.Location = new System.Drawing.Point(899, 22);
            this.btnChineseAdd.Name = "btnChineseAdd";
            this.btnChineseAdd.Size = new System.Drawing.Size(64, 27);
            this.btnChineseAdd.TabIndex = 3;
            this.btnChineseAdd.Text = "保存";
            this.btnChineseAdd.Click += new System.EventHandler(this.btnChineseAdd_Click);
            // 
            // txtZh
            // 
            this.txtZh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtZh.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtZh.Location = new System.Drawing.Point(331, 39);
            this.txtZh.Name = "txtZh";
            this.txtZh.Size = new System.Drawing.Size(377, 24);
            this.txtZh.TabIndex = 2;
            // 
            // lbChineseZhIcd
            // 
            this.lbChineseZhIcd.AutoSize = true;
            this.lbChineseZhIcd.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.lbChineseZhIcd.Location = new System.Drawing.Point(769, 42);
            this.lbChineseZhIcd.Name = "lbChineseZhIcd";
            this.lbChineseZhIcd.Size = new System.Drawing.Size(0, 19);
            this.lbChineseZhIcd.TabIndex = 0;
            // 
            // txtBm
            // 
            this.txtBm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBm.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtBm.Location = new System.Drawing.Point(331, 8);
            this.txtBm.Name = "txtBm";
            this.txtBm.Size = new System.Drawing.Size(377, 24);
            this.txtBm.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label8.Location = new System.Drawing.Point(710, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "GB/T：";
            // 
            // lbChineseBmIcd
            // 
            this.lbChineseBmIcd.AutoSize = true;
            this.lbChineseBmIcd.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.lbChineseBmIcd.Location = new System.Drawing.Point(769, 11);
            this.lbChineseBmIcd.Name = "lbChineseBmIcd";
            this.lbChineseBmIcd.Size = new System.Drawing.Size(0, 19);
            this.lbChineseBmIcd.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label7.Location = new System.Drawing.Point(261, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "症    候：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label5.Location = new System.Drawing.Point(710, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "GB/T：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.label6.Location = new System.Drawing.Point(261, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "病    名：";
            // 
            // tabItem2
            // 
            this.tabItem2.AttachedControl = this.tcpChinese;
            this.tabItem2.Name = "tabItem2";
            this.tabItem2.Text = "中医诊断";
            this.tabItem2.Click += new System.EventHandler(this.tabItem2_Click);
            // 
            // tabControlPanel1
            // 
            this.tabControlPanel1.CanvasColor = System.Drawing.Color.Transparent;
            this.tabControlPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.tabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel1.Location = new System.Drawing.Point(0, 25);
            this.tabControlPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControlPanel1.Name = "tabControlPanel1";
            this.tabControlPanel1.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel1.Size = new System.Drawing.Size(1093, 517);
            this.tabControlPanel1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(179)))), ((int)(((byte)(231)))));
            this.tabControlPanel1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.tabControlPanel1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel1.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(97)))), ((int)(((byte)(156)))));
            this.tabControlPanel1.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel1.Style.GradientAngle = 90;
            this.tabControlPanel1.TabIndex = 3;
            this.tabControlPanel1.TabItem = this.tabItem3;
            // 
            // tabItem3
            // 
            this.tabItem3.AttachedControl = this.tabControlPanel1;
            this.tabItem3.Name = "tabItem3";
            this.tabItem3.Text = "常用诊断";
            this.tabItem3.Click += new System.EventHandler(this.tabItem3_Click);
            // 
            // elementStyle4
            // 
            this.elementStyle4.BackColor = System.Drawing.Color.White;
            this.elementStyle4.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(228)))), ((int)(((byte)(240)))));
            this.elementStyle4.BackColorGradientAngle = 90;
            this.elementStyle4.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle4.BorderBottomWidth = 1;
            this.elementStyle4.BorderColor = System.Drawing.Color.DarkGray;
            this.elementStyle4.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle4.BorderLeftWidth = 1;
            this.elementStyle4.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle4.BorderRightWidth = 1;
            this.elementStyle4.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle4.BorderTopWidth = 1;
            this.elementStyle4.CornerDiameter = 4;
            this.elementStyle4.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.elementStyle4.Description = "Gray";
            this.elementStyle4.Name = "elementStyle4";
            this.elementStyle4.PaddingBottom = 1;
            this.elementStyle4.PaddingLeft = 1;
            this.elementStyle4.PaddingRight = 1;
            this.elementStyle4.PaddingTop = 1;
            this.elementStyle4.TextColor = System.Drawing.Color.Black;
            // 
            // elementStyle3
            // 
            this.elementStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(230)))), ((int)(((byte)(247)))));
            this.elementStyle3.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(168)))), ((int)(((byte)(228)))));
            this.elementStyle3.BackColorGradientAngle = 90;
            this.elementStyle3.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle3.BorderBottomWidth = 1;
            this.elementStyle3.BorderColor = System.Drawing.Color.DarkGray;
            this.elementStyle3.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle3.BorderLeftWidth = 1;
            this.elementStyle3.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle3.BorderRightWidth = 1;
            this.elementStyle3.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle3.BorderTopWidth = 1;
            this.elementStyle3.CornerDiameter = 4;
            this.elementStyle3.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.elementStyle3.Description = "Blue";
            this.elementStyle3.Name = "elementStyle3";
            this.elementStyle3.PaddingBottom = 1;
            this.elementStyle3.PaddingLeft = 1;
            this.elementStyle3.PaddingRight = 1;
            this.elementStyle3.PaddingTop = 1;
            this.elementStyle3.TextColor = System.Drawing.Color.Black;
            // 
            // elementStyle2
            // 
            this.elementStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(230)))), ((int)(((byte)(247)))));
            this.elementStyle2.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(168)))), ((int)(((byte)(228)))));
            this.elementStyle2.BackColorGradientAngle = 90;
            this.elementStyle2.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle2.BorderBottomWidth = 1;
            this.elementStyle2.BorderColor = System.Drawing.Color.DarkGray;
            this.elementStyle2.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle2.BorderLeftWidth = 1;
            this.elementStyle2.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle2.BorderRightWidth = 1;
            this.elementStyle2.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.elementStyle2.BorderTopWidth = 1;
            this.elementStyle2.CornerDiameter = 4;
            this.elementStyle2.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.elementStyle2.Description = "Blue";
            this.elementStyle2.Name = "elementStyle2";
            this.elementStyle2.PaddingBottom = 1;
            this.elementStyle2.PaddingLeft = 1;
            this.elementStyle2.PaddingRight = 1;
            this.elementStyle2.PaddingTop = 1;
            this.elementStyle2.TextColor = System.Drawing.Color.Black;
            // 
            // frmDiagnoseSimple
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1095, 544);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MinimizeBox = false;
            this.Name = "frmDiagnoseSimple";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "诊断编辑";
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tcDiagnose)).EndInit();
            this.tcDiagnose.ResumeLayout(false);
            this.tcpWestern.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.atDiagnoseList)).EndInit();
            this.cmsDiagnose.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tcpChinese.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.atChineseDiagnose)).EndInit();
            this.cmsChineseDiagnose.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar1;
        private DevComponents.DotNetBar.LabelItem labelItem1;
        private System.Windows.Forms.Panel panel1;
        private DevComponents.DotNetBar.LabelItem labelItem2;
        private DevComponents.DotNetBar.ButtonItem biUp;
        private DevComponents.DotNetBar.ButtonItem biDown;
        private DevComponents.DotNetBar.ButtonX btnAdd;
        private System.Windows.Forms.Label lblIcd10Encode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip cmsDiagnose;
        private System.Windows.Forms.ToolStripMenuItem 添加附属诊断ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 修改诊断ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除诊断ToolStripMenuItem;
        private DevComponents.DotNetBar.ButtonX btnClear;
        private DevComponents.AdvTree.AdvTree atDiagnoseList;
        private DevComponents.DotNetBar.ElementStyle elementStyle1;
        private DevComponents.AdvTree.NodeConnector nodeConnector1;
        private DevComponents.DotNetBar.ElementStyle elementStyle4;
        private DevComponents.DotNetBar.ElementStyle elementStyle3;
        private DevComponents.DotNetBar.ElementStyle elementStyle2;
        private DevComponents.AdvTree.Node node1;
        private DevComponents.AdvTree.Node node2;
        private DevComponents.DotNetBar.TabControl tcDiagnose;
        private DevComponents.DotNetBar.TabControlPanel tcpWestern;
        private DevComponents.DotNetBar.TabItem tabItem1;
        private DevComponents.DotNetBar.TabControlPanel tcpChinese;
        private DevComponents.DotNetBar.TabItem tabItem2;
        private DevComponents.AdvTree.AdvTree atChineseDiagnose;
        private DevComponents.AdvTree.Node node3;
        private DevComponents.AdvTree.Node node4;
        private DevComponents.AdvTree.NodeConnector nodeConnector2;
        private DevComponents.DotNetBar.RibbonBar ribbonBar2;
        private DevComponents.DotNetBar.LabelItem labelItem3;
        private DevComponents.DotNetBar.CheckBoxItem checkBoxItem1;
        private DevComponents.DotNetBar.LabelItem labelItem4;
        private DevComponents.DotNetBar.ButtonItem buttonItem1;
        private DevComponents.DotNetBar.ButtonItem buttonItem2;
        private System.Windows.Forms.Panel panel3;
        private DevComponents.DotNetBar.ButtonX btnChineseClear;
        private DevComponents.DotNetBar.ButtonX btnChineseAdd;
        private System.Windows.Forms.Label lbChineseZhIcd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbChineseBmIcd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private DevComponents.AdvTree.ColumnHeader columnHeader1;
        private DevComponents.AdvTree.ColumnHeader columnHeader2;
        private System.Windows.Forms.ContextMenuStrip cmsChineseDiagnose;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private DevComponents.AdvTree.ColumnHeader columnHeader3;
        private DevComponents.AdvTree.ColumnHeader columnHeader4;
        private TextEditor.TextDocument.Control.AutoTextBox txtDiagnose;
        private TextEditor.TextDocument.Control.AutoTextBox txtZh;
        private TextEditor.TextDocument.Control.AutoTextBox txtBm;
        private DevComponents.AdvTree.ColumnHeader columnHeader5;
        private DevComponents.AdvTree.ColumnHeader columnHeader6;
        private DevComponents.AdvTree.ColumnHeader columnHeader7;
        private DevComponents.AdvTree.ColumnHeader columnHeader8;
        private DevComponents.AdvTree.ColumnHeader columnHeader9;
        private DevComponents.AdvTree.Cell cell1;
        private DevComponents.AdvTree.Cell cell2;
        private DevComponents.AdvTree.Cell cell3;
        private DevComponents.AdvTree.Cell cell4;
        private DevComponents.AdvTree.Cell cell5;
        private DevComponents.AdvTree.Cell cell6;
        private DevComponents.DotNetBar.ButtonItem buttonItem3;
        private DevComponents.AdvTree.ColumnHeader columnHeader10;
        private DevComponents.AdvTree.ColumnHeader columnHeader11;
        private DevComponents.AdvTree.ColumnHeader columnHeader12;
        private DevComponents.AdvTree.ColumnHeader columnHeader13;
        private DevComponents.AdvTree.ColumnHeader columnHeader14;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private DevComponents.AdvTree.ColumnHeader columnHeader15;
        private DevComponents.AdvTree.Cell cell7;
        private System.Windows.Forms.ToolStripMenuItem 复制诊断ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private DevComponents.DotNetBar.CheckBoxItem checkBoxItem2;
        private DevComponents.DotNetBar.ButtonItem buttonItem4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ToolStripMenuItem 复制诊断到ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private DevComponents.AdvTree.ColumnHeader columnHeader16;
        private DevComponents.AdvTree.ColumnHeader columnHeader17;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ToolStripMenuItem 添加为常用诊断ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加为常用诊断ToolStripMenuItem1;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel1;
        private DevComponents.DotNetBar.TabItem tabItem3;

    }
}